# Responsive Image Slider ver.2

A Pen created on CodePen.

Original URL: [https://codepen.io/Taluska/pen/eYqmXpJ](https://codepen.io/Taluska/pen/eYqmXpJ).

Improvements:
- Thumbnail sneak peek on smaller resolutions
- Scroll-Snap