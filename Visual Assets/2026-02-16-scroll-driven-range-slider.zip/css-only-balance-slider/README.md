# CSS Only Balance Slider 🤯

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/oNVwLpK](https://codepen.io/jh3y/pen/oNVwLpK).

